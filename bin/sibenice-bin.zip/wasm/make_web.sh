#!/usr/bin/env bash

printf "npm v"
npm -v
echo "-----------"
npm update
