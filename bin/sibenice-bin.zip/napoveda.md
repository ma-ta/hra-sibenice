```
+-------------------+-------------------------------+-------------------+
|                   |                               |                   |
|     ooooooooo     | +---+---+---+---+             |     ooooooooo     |
|   oo   o o   oo   | | N | A | P | O |             |   oo   O o   oo   |
|  ooo    |    ooo  | +---+---+---+---+---+---+---+ |  ooo    |    ooo  |
|  oo  ~~ - ~~  oo  |             | V | E | D | A | |  oo  ~~ O ~~  oo  |
|   ooooooooooooo   |             +---+---+---+---+ |   ooooooooooooo   |
|                   |                               |                   |
+-------------------+-------------------------------+-------------------+


                    Vitejte ve hre  S i _ e _ i c e !


Cilem  hry je v kazdem kole odkryt tajne slovo, jehoz delka je na zacatku
vyznacena podtrzitky:

                            >  r o _ i n _  .

Kazde  kolo  z celkem 9 zacina s 11 zivoty, ktere pote ubyvaji s chybnymi
pokusy.  Z  daneho  kola  si odnesete pocet bodu rovnajici se zbyvajicimu
poctu  zivotu a body se v prubehu hry scitaji do celkoveho skore. Paklize
nektere slovo neuhodnete pred vycerpanim vsech 11 zivotu, prohravate.


POPIS PRVKU HERNI OBRAZOVKY


Dale  jsou  popsany  graficke  prvky  vyskytujici  se  na herni obrazovce
a uveden jejich vyznam.



                               +--------+
                               | ZIVOTY |
                               | / BODY |
                               |--------|
  zbyvajici zivoty  (body) ->  | 01 /   |
  v aktualnim kole             |   / 11 |  <- celkovy pocet nasbiranych
                               +--------+     bodu z minulych kol



         +-----+-----+-----+-----+-----+-----+-----+-----+-----+
         |  1  | >2< |  3  |  4  |  5  |  6  |  7  |  8  |  9  |
         +-----+--|--+-----+-----+-----+-----+-----+-----+-----+
                  |
                  +--> ukazatel aktualne probihajiciho
                       kola hry



                  +--> hadane slovo s delkou vyznacenou
                  |    znaky ________
                  |
         +-----+--|--+-----+-----+-----+-----+-----+-----+-----+
         |        |                                |           |
         |     >  _i_e_ice                         |   ZASAH   |
         |                                         |     |     |
         +-----+-----+-----+-----+-----+-----+-----+-----|-----+
                                                         |
                informace o vysledku predchoziho tahu <--+



            +--> seznam aktualne dostupnych pismen
            |
         +-----+-----+-----+-----+-----+-----+-----+-----+-----+
         |  A  |  B  |  C  |  D  |  E  |  F  |  G  |  H  |  I  |
         +-----+-----+-----+-----+-----+-----+-----+-----+-----+
         |  J  |  K  |  L  |  M  |  N  |  O  |  P  |  Q  |  R  |
         +-----+-----+-----+-----+-----+-----+-----+-----+-----+
         |  S  |  T  |  U  |  V  |  W  |  X  |  Y  |  Z  |
         +-----+-----+-----+-----+-----+-----+-----+-----+
         Hadej pismeno (*) > 
                             |
                             +--> hvezdicku pro rychle volby
                                  (napr. 0 kdykoli ukonci hru)



-------------------------------------------------------------------------

                                                            Hodne stesti!
                                                (c) 2022-25  Martin TABOR
```