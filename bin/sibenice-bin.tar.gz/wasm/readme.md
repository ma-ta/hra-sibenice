⚠️ Z technických důvodů nelze otevřít soubor [index.html] přímo v prohlížeči,  
ale je nutný přístup přes jakýkoli jednoduchý webový server. Např.
- Node.js (npm):  
  [npx http-server .],
- Live Preview pro VS Code  
  [https://marketplace.visualstudio.com/items/?itemName=ms-vscode.live-server].
